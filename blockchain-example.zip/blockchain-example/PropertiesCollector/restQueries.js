
// Use Winston library for logging
const winston = require('winston');
const LOG = winston.loggers.get('application');
var request = require('request');

// Class that provides access to the Hyperledger Composer Network REST Api
class RestQueries {

    constructor(restApiAddr) {
        this._restApiAddr = restApiAddr
    }    

    callApi(processFunction,queryName){
        request.get(this._restApiAddr + "/api/queries/"+queryName, { json: true }, 
            (err, res, body) => {
                if (err) { 
                    return console.log(err);
                } else {	
                    processFunction(body)		
                }
            });  
    }

    getAllProperties(processFunction){
        this.callApi(processFunction,"selectProperties")
    }

    getPropertiesForSale(processFunction){
        this.callApi(processFunction,"selectPropertiesForSale")
    }


    propertiesOfUser(userId,processFunction){
        this.callApi(processFunction,"selectMyProperites?owner=resource%3Acom.automic.middleEarth.properties.User%23"+userId)
    }

    allUsers(processFunction){
        this.callApi(processFunction,"selectAllUsers")
    }
}

module.exports.RestQueries = RestQueries;