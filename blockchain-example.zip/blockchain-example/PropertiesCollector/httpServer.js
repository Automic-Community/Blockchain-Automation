// Use Winston library for logging
const winston = require('winston');
const LOG = winston.loggers.get('application');

let http = require('http')
let pages = require('./pages.js')
let url = require('url') 
let fs = require('fs')


class HttpServer{

    constructor(restQueries) {
        this._pages = new pages.Pages(restQueries);
    }   

    start(portNr){
        var pages = this._pages

        http.createServer(function(req, response) {             
            var urlObject = url.parse(req.url,true);
            
            LOG.info(urlObject.pathname.toLocaleLowerCase())
            
            switch(urlObject.pathname.toLocaleLowerCase()){
                case '/getall':
                    pages.getAllProperties(response);
                    break
            
                case '/forsale':
                    pages.getPropertiesForSale(response);
                    break
            
                case '/myproperties':
                    if ("userId" in urlObject.query){
                        var userId = urlObject.query['userId']  
                        LOG.info(userId)
                        pages.propertiesOfUser(response,userId);
                    }
                    break
            
                case '/users':
                    pages.allUsers(response);
                    break
                
                case '/style.css':
                    fs.readFile('pages/css/style.css', function (err, data) {
                        if (err) {
                            response.writeHead(404, { 'Content-Type': 'text/css' });                            
                            response.end();
                        }else{
                            response.writeHead(200, { 'Content-Type': 'text/css' });
                            response.end(data, 'utf-8');
                            response.end();
                            }
                        });
                    break
                                
                default:
                    response.writeHead(404, { 'Content-Type': 'text/css' });                            
                    response.end();
                }
    
        }).listen(portNr, '0.0.0.0');
   
       }

    sendStyleFile(response){
        
    }
}

module.exports.HttpServer = HttpServer;