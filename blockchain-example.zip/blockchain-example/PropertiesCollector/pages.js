const winston = require('winston');
const LOG = winston.loggers.get('application');
var request = require('request');
var pug = require("pug")

class Pages{

    constructor(queries) {
        // compile all pug templates that we will need to render the pages
        LOG.info("Compiling pug templates.")
        this._listPage = pug.compileFile("pages/propertiesList.pug");
        this._userPage = pug.compileFile("pages/usersList.pug");
        this._queries = queries
    }  

    // since we render all the property queries with the same pug template 
    // we need only to apply different functions to load the data
    // propertyQuery parameter is the function that will be applied and the response is the stream
    // where we will paste the rendered page
    loadProperties(propertyQuery,response){
        var queries = this._queries
        var listPages = this._listPage

        propertyQuery.call(queries,function(props){
            queries.allUsers(function(allUsers){
                response.writeHead(200, {'Content-Type': 'text/html'});
               // to be able to reference the data about the users from the properties I need
               // to provide the data as a associative array with the full ID of the user as a key
                var userMap = {}                
                for (var i=0;i< allUsers.length;i++){
                    userMap["resource:com.automic.middleEarth.properties.User#"+allUsers[i]["userID"]] = allUsers[i]["name"]
                }                

                response.write(listPages({
                    properties:props,
                    users:userMap}))
                response.end()
            })
        });
    }

    getAllProperties(response){
        this.loadProperties(this._queries.getAllProperties,response)
    }

    getPropertiesForSale(response){
        this.loadProperties(this._queries.getPropertiesForSale,response)
    }

    propertiesOfUser(response,userId){
        var queries = this._queries
        var listPages = this._listPage

        queries.propertiesOfUser(userId,function(props){
            queries.allUsers(function(allUsers){
                response.writeHead(200, {'Content-Type': 'text/html'});
                var userMap = {}                
                for (var i=0;i< allUsers.length;i++){
                    userMap["resource:com.automic.middleEarth.properties.User#"+allUsers[i]["userID"]] = allUsers[i]["name"]
                }   
                response.write(listPages({
                    properties:props,
                    users:userMap}))
                response.end()
            })
        });
    }

    allUsers(response){        
        var userPage = this._userPage
      
        this._queries.allUsers(function(allUsers){
            response.writeHead(200, {'Content-Type': 'text/html'});
            response.write(userPage({users:allUsers}))
            response.end()
        })
    }

}

module.exports.Pages = Pages;