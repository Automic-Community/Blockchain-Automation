
const BusinessNetworkConnection = require('composer-client').BusinessNetworkConnection;

// Use Winston library for logging
const winston = require('winston');
const LOG = winston.loggers.get('application');
var request = require('request');

class RealEstatePropertiesNetwork{

    constructor(card) {
        // Load configuration needed to be able to connect to the Hyperledger network
        this._card = card;
        this._bizNetworkConnection = new BusinessNetworkConnection();
        this._businessNetworkDefinition = null
        this.connect();
    }  

    connect(){
        // Establish a connection to they Hyperledger network
        LOG.info("Establishing connection to the Hyperledger network");
        this._bizNetworkConnection.connect(this._card)
    	    .then((result) => {
                this._businessNetworkDefinition = result;
                LOG.info("Connected to the network "+this._businessNetworkDefinition.getIdentifier());               
            }).catch(function (error) {
	            throw error;
            });

    }

    getConnection(){
        return this._bizNetworkConnection;
    }
    
    listenHyperledgerEvents(callObject,callMethod){
        LOG.info("Register the listener to the Hyperledger Network events.");
        this.getConnection().on('event',(evt)=>{	
            LOG.info("Received an event from hyperledger network.");
            callMethod.call(callObject,evt)
        })	
    }
}

module.exports.RealEstatePropertiesNetwork = RealEstatePropertiesNetwork