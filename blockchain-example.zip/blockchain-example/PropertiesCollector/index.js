
'use strict';

// Use Winston library for logging
const winston = require('winston');
const LOG = winston.loggers.get('application');

// load configuration file
let config = require('config')

// Initialize connection to the hyperledger network.
function buildHyperledgerNetworkConnection(config){
	// Load configuration needed to be able to connect to the Hyperledger network
	let networkProperties = config.get('real-estate-network');
	let CARD = networkProperties.get('card');

	var hyperledgerNetwork = require('./bizNetEventsListener.js')
	return new hyperledgerNetwork.RealEstatePropertiesNetwork(CARD)
}

// Initialize connection to the event engine.
function buildEventEngineConnection(config){
	let eventEngineProperties = config.get('event-engine');
	var engine = require('./eventEngine.js')
	let ENGINE_AUTHORIZATION_KEY = eventEngineProperties.get('authorizationKey');
	let ENGINE_URL = eventEngineProperties.get('engineUrl');
	var EVENT_DEFINITION = eventEngineProperties.get('eventDefinition');
	
	return new engine.EventEngine(ENGINE_AUTHORIZATION_KEY,ENGINE_URL,EVENT_DEFINITION);		
}

// Register the listener to the Hyperledger business network
var eventEngine = buildEventEngineConnection(config)
var hyperledgerConnection = buildHyperledgerNetworkConnection(config)
hyperledgerConnection.listenHyperledgerEvents(eventEngine,eventEngine.sendEvent)

var restQueries = require('./restQueries.js')
var restApiAddr = config.get("rest-api").get("url")
var queries = new restQueries.RestQueries(restApiAddr)

let server = require("./httpServer.js")
var httpServer = new server.HttpServer(queries);
httpServer.start(3500);