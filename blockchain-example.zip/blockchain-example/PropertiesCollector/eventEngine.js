// Use Winston library for logging
const winston = require('winston');
const LOG = winston.loggers.get('application');
var request = require('request');

class EventEngine {
    
        constructor(authKey,eventEngineUrl,eventDef) {
            this._authorizationKey = authKey
            this._engineUrl = eventEngineUrl
            this._eventDefinition = eventDef
        }    
    
        /** Send Event to the Event Engine*/
        sendEvent(event){                 
            try { 
                
                 var hdr = {
                    "Authorization": this._authorizationKey,
                    "Content-Type": "application/json"
                }			
                
                var content = {
                    "type": this._eventDefinition,
                    "values":{
                            'name': event.name,
                            "isForSale": true,
                            "id": "resource:com.automic.middleEarth.properties.Property#"+event.id,
                            "price": event.price,
                            "location": event.location,						
                            "userID": event.userID,
                            "userTitle": event.userTitle,
                            "userName": event.userName
                        }
                    };
                      
                // Configure the request
                var opt = {
                    url: this._engineUrl,
                    method: 'POST',
                    json: true,
                    headers: hdr,
                    body: content
                }
            }catch(err){
                LOG.error(err);
            }
                
            // Start the request
            request(opt, function (error, response, body) {
                if (!error && response.statusCode == 200) {					
                    LOG.info("Event successfully send to the Event Engine.");
                }else{					
                    LOG.debug(response);
                    LOG.error(error);
                    }
                });         
         }
}

module.exports.EventEngine = EventEngine;